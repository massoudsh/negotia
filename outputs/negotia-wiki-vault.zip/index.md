# Index

> این فایل توسط ایجنت ساخته و نگهداری می‌شود. ابتدا با bootstrap پر می‌شود
> و سپس با هر ingest/query به‌روز می‌ماند.

## Overview
- [[overview]] — Negotia، ایجنت هوشمند اجرای تجارت خارجی؛ مسئله، راه‌حل، وضعیت فعلی

## Entities (۳ صفحه)
- [[entities/data-model]] — factory functionهای Contact/Product/Conversation/Message/Proforma
- [[entities/policy-guardrails-engine]] — موتور بررسی پیشنهاد در برابر سیاست شرکت
- [[entities/proforma-flow]] — summarize → draftReply → followUp → approval → proforma

## Concepts (۲ صفحه)
- [[concepts/negotiation-flow]] — مسیر مرحله‌به‌مرحله مکالمه تا سفارش (صادرات و واردات)
- [[concepts/company-policy-guardrails]] — چارچوب سیاست‌های شرکت (کف قیمت، پرداخت، ظرفیت، تأیید انسانی)

## اسناد مرتبط خارج از ویکی
- `docs/product-vision.md` — چشم‌انداز کامل محصول
- `docs/roadmap.md` — نقشه راه فازبندی‌شده
- `scripts/create-github-issues.sh` — اسکریپت ساخت ایشوهای اولیه در گیت‌هاب
