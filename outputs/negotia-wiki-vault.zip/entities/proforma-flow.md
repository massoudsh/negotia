# Proforma Preparation & Approval Flow

> پیاده‌سازی مراحل ۴ تا ۶ [[concepts/negotiation-flow]] — issueهای #6, #7, #9, #10, #11.

## مسئولیت‌ها
- `summarizeConversation` (issue #6): خلاصه + `intent` + `seriousness` (`low|medium|high`) از طریق `src/llm/provider.js` (پیش‌فرض mock rule-based، طبق `docs/adr/0001-tech-stack.md`).
- `draftReply` (issue #7): پیش‌نویس پاسخ انگلیسی + سؤال‌های لازم برای اطلاعات ناقص (quantity/specs/destination).
- `scheduleFollowUp` (issue #9): اگر آخرین پیام از طرف شرکت بوده و `waitDays` گذشته، `needsFollowUp=true`.
- `prepareProforma` (issue #11): `checkOffer` را اجرا و proforma را با `status='pending_approval'` می‌سازد.
- `createApprovalRequest` / `approve` / `reject` / `guardSend` (issue #10): `guardSend` تا وقتی status !== 'approved' است throw می‌کند — هیچ پیام/پیش‌فاکتوری بدون تأیید انسانی «ارسال‌پذیر» نیست.

## وابستگی‌ها
- [[entities/policy-guardrails-engine]] — ورودی violations برای proforma.
- [[entities/data-model]] — ساخت `Proforma`.

## منابع کد
- `src/negotiation/summarize.js`, `src/negotiation/draftReply.js`
- `src/followup/scheduler.js`
- `src/approval/checkpoint.js`
- `src/proforma/prepare.js`
- تست‌ها: `test/*.test.js` (اجرا: `npm test` یا `node --test test/`)
