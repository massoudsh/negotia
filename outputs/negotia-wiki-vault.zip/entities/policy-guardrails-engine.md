# Policy Guardrails Engine

> پیاده‌سازی [[concepts/company-policy-guardrails]] — issue #8.

## مسئولیت‌ها
- `checkOffer(offer, policy)` هر پیشنهاد (قیمت، شرایط پرداخت، تحویل، کشور/مشتری) را در برابر `config/policy.schema.json` بررسی می‌کند.
- خروجی: `{ allowed, requiresHumanApproval, violations[], adjustedDeliveryDays? }`.

## وابستگی‌ها
- `config/policy.example.json` — نمونه پیکربندی سیاست شرکت.
- [[entities/proforma-flow]] — نتیجه guardrails مستقیم در proforma قرار می‌گیرد.

## قراردادها / Edge cases (پیاده‌سازی‌شده طبق wiki concept)
- زیر کف قیمت → **رد نمی‌شود**، `requiresHumanApproval=true` می‌شود.
- کشور/مشتری حساس → violation `sensitive_party` + توقف برای تأیید انسانی.
- تحویل بیشتر از ظرفیت واقعی → `adjustedDeliveryDays` خودکار محاسبه می‌شود (بر اساس `productionCapacity`)، تعهد بیشتر از ظرفیت داده نمی‌شود.

## منابع کد
- `src/policy/guardrails.js:12` — `checkOffer`
- `config/policy.schema.json` — schema رسمی
