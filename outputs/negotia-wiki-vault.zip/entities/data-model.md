# مدل داده (Contact, Product, Conversation, Message, Proforma)

> Factory functionهای موجودیت‌های اصلی پروژه (issue #2).

## مسئولیت‌ها
- ساخت شیء اولیه هر entity با id (`crypto.randomUUID`) و timestamp.
- `Conversation` آرایه `messages` را نگه می‌دارد (بدون DB واقعی در MVP فعلی).

## وابستگی‌ها
- [[concepts/negotiation-flow]] — این entityها بستر پیاده‌سازی مسیر مذاکره هستند.
- [[concepts/company-policy-guardrails]] — `Proforma.violations` خروجی guardrails را نگه می‌دارد.

## قراردادها / Edge cases
- `Proforma.status` یکی از `draft | pending_approval | approved | rejected` است؛ هرگز مستقیم به `approved` ساخته نمی‌شود — باید از [[entities/approval-checkpoint]] عبور کند.
- جزئیات کامل فیلدها: `docs/data-model.md`.

## منابع کد
- `src/models/index.js:1` — همه factory functionها
