# Log

> تاریخچه append-only — هر ورود با `## [YYYY-MM-DD] <type> | <خلاصه>` شروع می‌شود.

## [2026-07-26] update | ساخت اسکلت اولیه ریپو (README, LICENSE, docs/product-vision) + wiki (overview, concepts/negotiation-flow, concepts/company-policy-guardrails) + docs/roadmap.md + scripts/create-github-issues.sh
## [2026-08-15] update | حل issueهای #1 تا #11: ADRهای Phase 0 (stack، کانال ورودی)، مدل داده و schema سیاست شرکت، و پیاده‌سازی کامل منطق MVP (ingest ایمیل، summarize، draftReply، guardrails، follow-up scheduler، approval checkpoint، proforma) با ۲۳ تست عبورشده در `src/` و `test/`
